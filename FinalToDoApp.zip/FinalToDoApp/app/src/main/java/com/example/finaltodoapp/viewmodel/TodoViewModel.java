package com.example.finaltodoapp.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.finaltodoapp.data.TodoRepository;
import com.example.finaltodoapp.model.entity.Etodo;

import java.util.List;

public class TodoViewModel extends AndroidViewModel {
    private TodoRepository mTodoRepository;
    private LiveData<List<Etodo>> mAllTodos;

    public TodoViewModel(@NonNull Application application){
        super(application);

        mTodoRepository = new TodoRepository(application);
        mAllTodos=mTodoRepository.getAllTodoList();
    }
    public void insert(Etodo todo){
        mTodoRepository.insert(todo);
    }

    public void update(Etodo todo){
        mTodoRepository.update(todo);
    }

    public LiveData<List<Etodo>> getAllTodoList() {
        return mAllTodos;
    }

    public Etodo getTodoById(int id){
        return mTodoRepository.getTodoById(id);
    }

    public void deleteById(Etodo todo){
        mTodoRepository.deleteById(todo);
    }

    public void deleteAll(){
        mTodoRepository.deleteAll();
    }
}
