package com.example.finaltodoapp.data;

import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteQuery;

import com.example.finaltodoapp.model.entity.Etodo;

import java.util.Date;

@Database(entities = {Etodo.class},version = 1,exportSchema = false)
public abstract class TodoRoomDatabase extends RoomDatabase {
    public abstract TodoDAO mtodoDAO();

    private static TodoRoomDatabase INSTANCE;
    public static TodoRoomDatabase getDatabase(Context context){
        if(INSTANCE==null){
            synchronized (TodoRoomDatabase.class){
                if (INSTANCE==null){
                    INSTANCE= Room.databaseBuilder(context.getApplicationContext(),
                    TodoRoomDatabase.class,"todo.db")
                            .allowMainThreadQueries()
                            .fallbackToDestructiveMigration()
                            .addCallback(sCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static class populateDbAsynchTask extends AsyncTask<Etodo,Void,Void> {
        private TodoDAO mTodoDAO;
        private populateDbAsynchTask(TodoRoomDatabase db){
            mTodoDAO=db.mtodoDAO();
        }

        @Override
        protected Void doInBackground(Etodo... todos) {
            Date date = new Date();
            Etodo todo = new Etodo("Demo Title","Demo Description",date,1,false);
            mTodoDAO.insert(todo);
            return null;
        }
    }

    private static RoomDatabase.Callback sCallback= new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new populateDbAsynchTask(INSTANCE).execute();
        }
    };

}
